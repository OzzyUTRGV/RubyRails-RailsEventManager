class Event < ApplicationRecord
end
